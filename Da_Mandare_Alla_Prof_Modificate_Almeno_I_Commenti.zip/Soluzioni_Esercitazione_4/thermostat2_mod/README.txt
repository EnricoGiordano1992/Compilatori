PER VERIFICARE IL FILE

All'avvio, impostare la temperatura:

target temperature <number>

dopo leggere la temperatura

read <number>

se <number> è uguale alla temperatura precedentemente impostata, si scriverà a video

TEMPERATURA RAGGIUNTA
